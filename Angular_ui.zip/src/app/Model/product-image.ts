export class ProductImage {

    id? : number;
    data? :[];

    constructor(id:number , data:[]){
        this.id = id;
        this.data = data;
    }
}
