import { ProductImage } from './product-image';

describe('ProductImage', () => {
  it('should create an instance', () => {
    expect(new ProductImage()).toBeTruthy();
  });
});
