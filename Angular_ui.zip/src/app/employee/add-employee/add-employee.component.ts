import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Employee } from 'src/app/Model/employee.model';
import { EmployeeService } from 'src/app/Services/employee.service';
import { specialCharValidator } from 'src/app/Shared/specialCharValidator.validator';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent {

  empId = '';
  firstName = '';
  lastName = '';
  salary = '';
  address = '';
  email = '';
  phone = '';
  responseData: any;



  form = new FormGroup({
    empId: new FormControl('', [Validators.required,specialCharValidator()]),
    firstName: new FormControl('', [Validators.required,specialCharValidator()]),
    lastName: new FormControl('', [Validators.required,specialCharValidator()]),
    salary: new FormControl('', [Validators.required,specialCharValidator()]),
    address: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required]),
    phone: new FormControl('', [Validators.required,Validators.maxLength(10),specialCharValidator()])
  });

  constructor(private http: HttpClient, private router: Router, private route : ActivatedRoute,
    private employeeServices : EmployeeService) {

  }
ngOnInit(){
  // this.route.params.subscribe((params:Params) => {
  //   const empId = params['empId'];
  //   this.employeeServices.getAllEmployees().subscribe((employee)=>{
  //     this.form.patchValue({
  //       empId: this.empId,
  //       firstName: this.firstName,
  //       lastName: this.lastName,
  //       salary: this.salary,
  //       address: this.address,
  //       email: this.email,
  //       phone: this.phone
  //     })
  //     });

   
  // });
}

  addEmployee() {
    if (this.form.valid) {
      this.http.post('http://localhost:8080/api/employee/addEmployee', {
        empId: this.empId,
        firstName: this.firstName,
        lastName: this.lastName,
        salary: this.salary,
        address: this.address,
        email: this.email,
        phone: this.phone
      })
        .subscribe(
          data => {
            console.log(data);
            this.responseData = data;
            this.router.navigate(['/listEmployees']);
          }
        )

    }
  }

}
