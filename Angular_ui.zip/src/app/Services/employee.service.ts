import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from '../Model/employee.model';
import { Observable, map } from 'rxjs';
import { ProductImage } from '../Model/product-image';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http: HttpClient) { }

  private apiUrl = 'http://localhost:8080/api/employee';

  private baseUrl = 'http://localhost:8080/api/products';

  getAllProducts(): Observable<any[]> {

    return this.http.get<any[]>(`${this.baseUrl}/allImages`);

  }
  getImageByid(imageId:number) :Observable<Blob>{
    return this.http.get(`${this.baseUrl}/image/${imageId}`,{
      responseType :'blob'
    });
  }

  getAllEmployees(): Observable<Employee[]> {

    return this.http.get<Employee[]>(`${this.apiUrl}/ListEmployees`);

  }
  getEmployeeById(empId:number):Observable<Employee>{
    return this.http.get<Employee>(`${this.apiUrl}/update/${empId}`)
  }

  deletebyid(empId: number) {
    return this.http.delete(`${this.apiUrl}/delete/${empId}`);
  }

  updatebyid(empId: number, employee: Employee): Observable<Employee> {
    return this.http.put<Employee>(`${this.apiUrl}/update/${empId}`, employee);
  }

  searchEmployees(query: string): Observable<Employee[]> {
    return this.http.get<Employee[]>(`${this.apiUrl}/search?query=${query}`);

  }
  searchEmployeesByFullName(query: string): Observable<Employee[]> {
    return this.http.get<Employee[]>(`${this.apiUrl}/searchFullName?query=${query}`);
  }

  // searchBySalary(): Observable<Employee[]> {
    
  //    return this.http.get(`${this.apiUrl}/salary`);
  // }

  searchBySalary(): Observable<Employee[]> {
    return this.http.get<Employee[]>(`${this.apiUrl}/salary`);

  }
}