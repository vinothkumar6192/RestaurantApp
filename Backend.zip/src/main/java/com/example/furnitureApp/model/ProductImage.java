package com.example.furnitureApp.model;

import jakarta.persistence.*;

@Entity
@Table(name = "productimage")
public class ProductImage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

//    private String filename;
//    private String contenttype;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

//    public String getFilename() {
//        return filename;
//    }
//
//    public void setFilename(String filename) {
//        this.filename = filename;
//    }
//
//    public String getContenttype() {
//        return contenttype;
//    }
//
//    public void setContenttype(String contenttype) {
//        this.contenttype = contenttype;
//    }


    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    @Lob
    private byte[] data;


}
