package com.example.furnitureApp.service;

import com.example.furnitureApp.model.Product;
import com.example.furnitureApp.model.ProductImage;
import com.example.furnitureApp.model.ProductRequest;
import com.example.furnitureApp.repository.ProductImageRepository;
import com.example.furnitureApp.repository.ProductRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductImageRepository productImageRepository;

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);

    }
    public Product addProduct(Product product) {
    return productRepository.save(product);
}

    public List<ProductImage> addImage(List<MultipartFile> imageFiles) {
        List<ProductImage> productImages = new ArrayList<>();
        for(MultipartFile imageFile : imageFiles){
            ProductImage productImage = new ProductImage();
            try {
                productImage.setData(imageFile.getBytes());
//                        comp(imageFile.getBytes());
//                compressBytes(file.getBytes()));



                productImages.add(productImage);
            }catch (IOException e){
                e.printStackTrace();
            }
        }
       return productImageRepository.saveAll(productImages);
////        productImage.setData(imageFile.getBytes());
//        try {
//
//
//            productImage.setData(imageFile.getBytes());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//       return productImageRepository.save(productImage);
    }

    public static byte[] compressBytes(byte[] data) {
        Deflater deflater = new Deflater();
        deflater.setInput(data);
        deflater.finish();

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
        byte[] buffer = new byte[1024];
        while (!deflater.finished()) {
            int count = deflater.deflate(buffer);
            outputStream.write(buffer, 0, count);
        }
        try {
            outputStream.close();
        } catch (IOException e) {
        }
        System.out.println("Compressed Image Byte Size - " + outputStream.toByteArray().length);

        return outputStream.toByteArray();
    }
    public static byte[] decompressBytes(byte[] data) {
        Inflater inflater = new Inflater();
        inflater.setInput(data);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
        byte[] buffer = new byte[1024];
        try {
            while (!inflater.finished()) {
                int count = inflater.inflate(buffer);
                outputStream.write(buffer, 0, count);
            }
            outputStream.close();
        } catch (IOException ioe) {
        } catch (DataFormatException e) {
        }
        return outputStream.toByteArray();
    }

    public ProductImage createProductImage(ProductImage productImage){
        return productImageRepository.save(productImage);
    }


    public List<ProductImage> getAllImages() {
        return productImageRepository.findAll();
    }

    public ResponseEntity<byte[]> getProductImageById(Long id){
        Optional<ProductImage> optionalProductImage = productImageRepository.findById(id);
        if(optionalProductImage.isPresent()){
            ProductImage productImage = optionalProductImage.get();
            return ResponseEntity.ok()
                    .contentType(MediaType.IMAGE_PNG)
                    .body(productImage.getData());
        }else{
            return ResponseEntity.notFound().build();
        }
    }
}
