package com.example.furnitureApp.controller;

import com.example.furnitureApp.model.Product;
import com.example.furnitureApp.model.ProductImage;
import com.example.furnitureApp.model.ProductRequest;
import com.example.furnitureApp.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/products")
public class ProductController {
    @Autowired
    private ProductService productService;

    @GetMapping
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    @GetMapping("/{id}")
    public Optional<Product> getProductById(@PathVariable Long id) {
        return productService.getProductById(id);
    }

//    @PostMapping("/create")
//    public Product createProduct(@RequestBody  Product product
//
////
////    @RequestParam("productName") String productName,
////    @RequestParam("description") String description,
////    @RequestParam("price") double price,
////    @RequestParam("quantity") int quantity
////            @RequestPart("imageFile") MultipartFile imageFile
////            @RequestParam("product") ProductRequest productRequest,
////            @RequestPart("imageFile") MultipartFile imageFile
//
//    ){
////             System.out.println("print" +productRequest);
//
////        return productService.createProduct(productName,description,price,quantity,imageFile);
//        return productService.createProduct(product);
////        product.setImage(productService.createProductImage(productImage));
////        return productService.createProduct(product);
//    }

//    @PostMapping("/addProduct")
//    public ResponseEntity<Product> addProduct(@RequestBody Product product) {
//
//        Product savedProduct = productService.addProduct(product);
//        return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);
//    }


    //    @PutMapping("{/id")
//    public Product updateProduct(@PathVariable Long id , @RequestBody Product product){
//        return productService
//    }
//    @GetMapping("/ListEmployees")
//    public ResponseEntity<List<Product>> getAllProducts() {
//        List<Product> products = productService.viewProducts();
//        if (!products.isEmpty()) {
//            return ResponseEntity.ok(products);
//        } else {
//            return ResponseEntity.noContent().build();
//        }
//    }
//
    @PostMapping("/addProduct")
    public ResponseEntity<Product> addProduct(@Valid @RequestBody Product product) {

        Product savedProduct = productService.addProduct(product);
        return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);
    }

    @PostMapping(value = "/create", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    public List<ProductImage> createProduct(@RequestPart("imageFile") List<MultipartFile> imageFiles) {
//        List<ProductImage> productImages = new ArrayList<>();
//        for (MultipartFile imageFile : imageFiles){
        return productService.addImage(imageFiles);

//            ProductImage productImage = productService.addImage(imageFile);
//        productImages.add(productImage);
//    }
//    return productImages;
//}
    }
    @GetMapping("/allImages")
    public List<ProductImage> getAllImages(){
        return productService.getAllImages();
    }

    @GetMapping("/image/{id}")
    public ResponseEntity<byte[]> getProductImage(@PathVariable Long id){
        return productService.getProductImageById(id);
    }


//    @PostMapping(value = "/upload")
//    public void postImage(@RequestParam("file") MultipartFile file) throws IOException {
//        System.out.println("received");
//    }

//    @RequestMapping(value = "/file", method = RequestMethod.POST)
//    public @ResponseBody String myService(@RequestParam("file") MultipartFile file) throws Exception {
//    return "File uploaded";
//    }
}
