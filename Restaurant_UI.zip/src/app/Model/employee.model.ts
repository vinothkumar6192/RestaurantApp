export class Employee {
    empId: number;
    firstName: string;
    lastName: string;
    salary: number;
    address: string;
    email: string;
    phone: number;

    isEditing: boolean | undefined;

    constructor(empId: number,
        firstName: string,
        lastName: string,
        address: string,
        phone: number,
        salary : number,
        email: string) {
        this.empId = empId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.salary = salary;
        this.address = address;
        this.email = email;
        this.phone = phone;



    }
}