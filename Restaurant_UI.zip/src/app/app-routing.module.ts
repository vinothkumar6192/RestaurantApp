import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { AddEmployeeComponent } from './employee/add-employee/add-employee.component';
import { EmployeeComponent } from './employee/employee.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ImagedisplayComponent } from './imagedisplay/imagedisplay.component';


const routes: Routes = [

  
  { path: 'addEmployee', component: AddEmployeeComponent },
  { path: 'listEmployees', component: EmployeeComponent},
  { path: '', component: DashboardComponent },
  { path: 'image', component: ImagedisplayComponent }

 


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
