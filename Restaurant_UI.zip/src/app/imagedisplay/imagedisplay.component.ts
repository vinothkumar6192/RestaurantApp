import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../Services/employee.service';
import { Router } from '@angular/router';
import { ProductImage } from '../Model/product-image';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-imagedisplay',
  templateUrl: './imagedisplay.component.html',
  styleUrls: ['./imagedisplay.component.css']
})
export class ImagedisplayComponent implements OnInit{
  // query: string = '';

  constructor(private employeeService: EmployeeService, private router: Router,private sanitizer:DomSanitizer) { }
  productImageIds: any[] = [];
  displayedImages:Map<number , string> = new Map<number,string>();
  ngOnInit() {

    this.employeeService.getAllProducts().subscribe((data :any[]) => {
      
        this.productImageIds = data;
        this.loadImages();
        console.log(this.productImageIds);
      
      });
      
  }
  loadImages():void{
    for(const imageId of this.productImageIds){
     
      this.employeeService.getImageByid(imageId).subscribe((data :Blob)=>{
        console.log(data);
        const reader = new FileReader();
        reader.onload = () =>{
          this.displayedImages.set(imageId,reader.result as string);
        };
        reader.readAsDataURL(data);
        console.log(data);
      });
    }

  }
  decodeBase64Image(data : string):string{
    return 'data:image/png;base64,' +data;
  }

}
