import { Component } from '@angular/core';
import { EmployeeService } from '../Services/employee.service';
import { Employee } from '../Model/employee.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent {
  query: string = '';

  constructor(private employeeService: EmployeeService, private router: Router) { }
  employees: Employee[] = [];

  ngOnInit() {

    this.employeeService.getAllEmployees().subscribe({
      next: data => {
        this.employees = data;
      },
      error: data => {
        console.error('Error retrieving employees data', Error);
      }

    });
  }

  deletebyid(id: number): void {
    this.employeeService.deletebyid(id)
      .subscribe(() => {
        console.log('Deleted successfully');
        this.refreshPage();
      },
        error => {
          console.error('error in deleting', error);
        });
  };

  refreshPage(): void {
    this.router.navigateByUrl('/listEmployees', { skipLocationChange: true }).then(() => {
      window.location.reload();
    })
  }

  updatebyid(empid: number, employee: Employee): void {
    this.employeeService.updatebyid(empid, employee).subscribe((UpdatedEmployee) => {
      console.log("Updated Successfully", UpdatedEmployee);
      const index = this.employees.findIndex(manage => manage.empId == UpdatedEmployee.empId);
      this.employees[index] = UpdatedEmployee;
      employee.isEditing = false;
    },
      error => {
        console.log("Error in updating");
      });
  }

  editEmployee(employee: Employee): void {
    employee.isEditing = true;
  }

  // editEmployees(empId : String){
  //   this.router.navigate(['/edit' , empId])
  // }
  Cancel() {
    this.refreshPage();
  }

  search(): void {
    if (this.query.trim() !== '') {
      this.employeeService.searchEmployees(this.query).subscribe(employees => {
        this.employees = employees;
      });
    }
    else {
      this.refreshPage();
    }
  }
  searchByFullname(): void {
    if (this.query.trim() !== '') {
      this.employeeService.searchEmployeesByFullName(this.query).subscribe(employees => {
        this.employees = employees;
      });
    }
    else {
      this.refreshPage();
    }
  }

  sortBySalary(): void {
    this.employeeService.searchBySalary()
      .subscribe((employees) => {
        console.log('Sorted Successfully');
        // this.refreshPage();
        this.employees = employees;
      },
        error => {
          console.error('error in searching', error);
        });
  };
}
