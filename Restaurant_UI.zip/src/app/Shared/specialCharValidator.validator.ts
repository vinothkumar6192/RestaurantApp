import { AbstractControl , ValidatorFn, Validators } from "@angular/forms";

export function specialCharValidator(): ValidatorFn {
    return(control : AbstractControl): {[key : string]: any} | null => {
        const value = control.value;
        if(value && /[^a-zA-Z0-9]/.test(value)){
            return {'specialCharacters' : true};
        }
        return null;
    };
} 

